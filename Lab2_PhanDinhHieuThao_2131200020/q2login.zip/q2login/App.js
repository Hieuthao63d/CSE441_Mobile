import React from 'react';
import LoginScreen from './Login/Login';

const App = () => {
  return (
    <LoginScreen />
  );
};

export default App;
